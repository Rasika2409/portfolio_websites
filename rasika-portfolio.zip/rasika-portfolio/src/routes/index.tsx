import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  Github, Linkedin, Code2, Mail, Phone, MapPin, Download, ArrowRight,
  Sun, Moon, GraduationCap, Briefcase, Award, Sparkles, Database,
  Globe, Coffee, Wrench, Brain, FolderGit2, Send, ExternalLink, Menu, X,
} from "lucide-react";
import rasikaPhoto from "@/assets/rasika.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Rasika Patil — CSE Student & Developer Portfolio" },
      { name: "description", content: "Rasika Raghunath Patil — B.Tech CSE student at Dr. D. Y. Patil College of Engineering, Kolhapur. Full Stack & Java developer with CGPA 9.22, open to internships." },
      { property: "og:title", content: "Rasika Patil — Developer Portfolio" },
      { property: "og:description", content: "CSE student, full stack & Java developer. CGPA 9.22. Open to internships." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Portfolio,
});

const SOCIALS = {
  linkedin: "https://www.linkedin.com/in/rasika-patil-166a31296",
  github: "https://rasika2409.github.io/Attendance_Management_System/",
  leetcode: "https://leetcode.com/u/rasikapatil2409/",
  email: "rasikapatil2409@gmail.com",
  phone: "7743887809",
};

const NAV = [
  { id: "home", label: "Home" },
  { id: "about", label: "About" },
  { id: "education", label: "Education" },
  { id: "skills", label: "Skills" },
  { id: "services", label: "Services" },
  { id: "experience", label: "Experience" },
  { id: "projects", label: "Projects" },
  { id: "certifications", label: "Certifications" },
  { id: "contact", label: "Contact" },
];

function useTyping(words: string[], speed = 80, pause = 1400) {
  const [text, setText] = useState("");
  const [i, setI] = useState(0);
  const [del, setDel] = useState(false);
  useEffect(() => {
    const w = words[i % words.length];
    const t = setTimeout(() => {
      if (!del) {
        setText(w.slice(0, text.length + 1));
        if (text.length + 1 === w.length) setTimeout(() => setDel(true), pause);
      } else {
        setText(w.slice(0, text.length - 1));
        if (text.length - 1 === 0) { setDel(false); setI((x) => x + 1); }
      }
    }, del ? speed / 2 : speed);
    return () => clearTimeout(t);
  }, [text, del, i, words, speed, pause]);
  return text;
}

function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll(".reveal-on-scroll");
    const io = new IntersectionObserver((entries) => {
      entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add("in-view"); });
    }, { threshold: 0.12 });
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

function Portfolio() {
  const [light, setLight] = useState(false);
  const [open, setOpen] = useState(false);
  const typed = useTyping(["Full Stack Developer", "Java Developer", "CSE Student", "Problem Solver"]);
  useReveal();

  useEffect(() => {
    document.documentElement.classList.toggle("light", light);
  }, [light]);

  const scrollTo = (id: string) => {
    setOpen(false);
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen text-foreground">
      <Nav onNav={scrollTo} open={open} setOpen={setOpen} light={light} setLight={setLight} />
      <Hero typed={typed} onNav={scrollTo} />
      <About />
      <Education />
      <Skills />
      <Services />
      <Experience />
      <Projects />
      <Certifications />
      <Contact />
      <Footer onNav={scrollTo} />
    </div>
  );
}

function Nav({ onNav, open, setOpen, light, setLight }: any) {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all ${scrolled ? "py-2" : "py-4"}`}>
      <div className={`mx-auto max-w-7xl px-4 ${scrolled ? "glass rounded-2xl mx-4 md:mx-auto" : ""}`}>
        <div className="flex items-center justify-between py-3">
          <button onClick={() => onNav("home")} className="font-display font-bold text-xl">
            <span className="gradient-text">Rasika</span>.dev
          </button>
          <nav className="hidden lg:flex items-center gap-1">
            {NAV.map((n) => (
              <button key={n.id} onClick={() => onNav(n.id)}
                className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground rounded-lg hover:bg-white/5 transition">
                {n.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <button onClick={() => setLight(!light)} aria-label="Toggle theme"
              className="p-2 rounded-lg glass hover:glow transition">
              {light ? <Moon className="size-4" /> : <Sun className="size-4" />}
            </button>
            <button onClick={() => onNav("contact")} className="hidden md:inline-flex items-center gap-2 px-4 py-2 rounded-lg gradient-bg text-white text-sm font-medium hover:glow transition">
              Hire Me <ArrowRight className="size-4" />
            </button>
            <button className="lg:hidden p-2 rounded-lg glass" onClick={() => setOpen(!open)} aria-label="Menu">
              {open ? <X className="size-4" /> : <Menu className="size-4" />}
            </button>
          </div>
        </div>
        {open && (
          <div className="lg:hidden pb-4 grid grid-cols-2 gap-2 animate-fade-in">
            {NAV.map((n) => (
              <button key={n.id} onClick={() => onNav(n.id)} className="px-3 py-2 text-sm text-left rounded-lg hover:bg-white/5">
                {n.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </header>
  );
}

function SocialIcons({ size = "size-5" }: { size?: string }) {
  const items = [
    { href: SOCIALS.linkedin, icon: Linkedin, label: "LinkedIn" },
    { href: SOCIALS.github, icon: Github, label: "GitHub" },
    { href: `https://leetcode.com/u/rasikapatil2409/`, icon: Code2, label: "LeetCode" },
  ];
  return (
    <div className="flex items-center gap-3">
      {items.map((s) => (
        <a key={s.label} href={s.href} target="_blank" rel="noreferrer" aria-label={s.label}
          className="p-3 rounded-xl glass hover:glow hover:-translate-y-1 transition-all duration-300">
          <s.icon className={size} />
        </a>
      ))}
    </div>
  );
}

function Hero({ typed, onNav }: { typed: string; onNav: (id: string) => void }) {
  return (
    <section id="home" className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-72 h-72 rounded-full bg-brand/30 blur-3xl animate-float" />
        <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-brand-2/20 blur-3xl animate-float" style={{ animationDelay: "2s" }} />
      </div>
      <div className="mx-auto max-w-7xl px-4 grid lg:grid-cols-[1.2fr_1fr] gap-12 items-center">
        <div className="space-y-6 animate-fade-in">
          <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground">
            <span className="size-2 rounded-full bg-emerald-400 animate-pulse" /> Open to internship opportunities
          </span>
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold leading-[1.05]">
            Hi, I'm <span className="gradient-text">Rasika Patil</span>
          </h1>
          <div className="text-xl md:text-2xl text-muted-foreground font-medium h-8">
            <span className="text-foreground">{typed}</span>
            <span className="animate-blink">|</span>
          </div>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl">
            Passionate Computer Science and Engineering student with internship experience in
            Full Stack Development and Java Programming. Dedicated to building practical software
            solutions and continuously expanding technical expertise.
          </p>
          <div className="flex flex-wrap gap-3 pt-2">
            <a href="/resume.pdf" download
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl gradient-bg text-white font-medium hover:glow hover:-translate-y-0.5 transition">
              <Download className="size-4" /> Download Resume
            </a>
            <button onClick={() => onNav("projects")}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl glass font-medium hover:glow transition">
              <FolderGit2 className="size-4" /> View Projects
            </button>
            <button onClick={() => onNav("contact")}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl border border-border font-medium hover:bg-white/5 transition">
              <Mail className="size-4" /> Contact Me
            </button>
          </div>
          <div className="pt-4"><SocialIcons /></div>
        </div>

        <div className="relative">
          <div className="absolute -inset-4 rounded-[2rem] gradient-bg opacity-30 blur-2xl animate-float" />
          <div className="relative glass rounded-[2rem] p-3 glow">
            <img src={rasikaPhoto} alt="Rasika Raghunath Patil" width={896} height={1152}
              className="w-full h-auto rounded-[1.5rem] object-cover" />
            <div className="absolute -bottom-4 -left-4 glass rounded-2xl px-4 py-3 glow">
              <div className="text-2xl font-bold gradient-text">9.22</div>
              <div className="text-xs text-muted-foreground">CGPA</div>
            </div>
            <div className="absolute -top-4 -right-4 glass rounded-2xl px-4 py-3 glow">
              <div className="text-2xl font-bold gradient-text">2027</div>
              <div className="text-xs text-muted-foreground">Graduating</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function SectionTitle({ kicker, title, subtitle }: { kicker: string; title: string; subtitle?: string }) {
  return (
    <div className="text-center max-w-2xl mx-auto mb-12 reveal-on-scroll">
      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-muted-foreground mb-4">
        <Sparkles className="size-3" /> {kicker}
      </div>
      <h2 className="text-3xl md:text-5xl font-bold"><span className="gradient-text">{title}</span></h2>
      {subtitle && <p className="mt-3 text-muted-foreground">{subtitle}</p>}
    </div>
  );
}

function About() {
  const stats = [
    { v: "9.22", l: "CGPA" },
    { v: "2027", l: "Expected Grad" },
    { v: "1+", l: "Internship" },
    { v: "3+", l: "Projects" },
  ];
  return (
    <section id="about" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4">
        <SectionTitle kicker="About Me" title="Building skills, shipping solutions" />
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 glass rounded-2xl p-8 reveal-on-scroll">
            <p className="text-muted-foreground leading-relaxed">
              I am a passionate Computer Science and Engineering student currently pursuing my B.Tech at
              Dr. D. Y. Patil Pratishtan's College of Engineering. With hands-on experience gained through
              internships in Full Stack Development and Java Programming, I have developed a strong foundation
              in software development, object-oriented programming, and problem-solving.
            </p>
            <p className="text-muted-foreground leading-relaxed mt-4">
              I enjoy building practical applications and continuously enhancing my technical skills in Java,
              Python, web technologies, and software engineering concepts.
            </p>
            <p className="text-muted-foreground leading-relaxed mt-4">
              My career goal is to become a skilled Software Developer and contribute to innovative projects
              that solve real-world problems. I am actively seeking internship opportunities where I can apply
              my knowledge, learn from industry professionals, and grow as a technology enthusiast.
            </p>
          </div>
          <div className="glass rounded-2xl p-6 reveal-on-scroll">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 rounded-xl gradient-bg text-white"><GraduationCap className="size-5" /></div>
              <div>
                <div className="font-semibold">Education</div>
                <div className="text-xs text-muted-foreground">Active student</div>
              </div>
            </div>
            <div className="text-sm text-muted-foreground">B.Tech in Computer Science & Engineering</div>
            <div className="text-sm mt-1">Dr. D. Y. Patil Pratishtan's College of Engineering</div>
            <div className="text-xs text-muted-foreground mt-1">Kolhapur, Maharashtra</div>
          </div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          {stats.map((s) => (
            <div key={s.l} className="glass rounded-2xl p-6 text-center reveal-on-scroll hover:glow hover:-translate-y-1 transition">
              <div className="text-3xl md:text-4xl font-bold gradient-text">{s.v}</div>
              <div className="text-xs text-muted-foreground mt-1">{s.l}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Education() {
  return (
    <section id="education" className="py-20 md:py-28">
      <div className="mx-auto max-w-5xl px-4">
        <SectionTitle kicker="Education" title="Academic Journey" />
        <div className="relative pl-8 md:pl-12">
          <div className="absolute left-2 md:left-4 top-2 bottom-2 w-px gradient-bg" />
          <div className="relative reveal-on-scroll">
            <div className="absolute -left-7 md:-left-10 top-2 size-4 rounded-full gradient-bg glow" />
            <div className="glass rounded-2xl p-6 md:p-8 hover:glow transition">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="text-sm text-muted-foreground">2023 — 2027 (Expected)</div>
                  <h3 className="text-xl md:text-2xl font-bold mt-1">B.Tech in Computer Science & Engineering</h3>
                  <div className="text-muted-foreground mt-1">Dr. D. Y. Patil Pratishtan's College of Engineering</div>
                  <div className="text-sm text-muted-foreground">Kolhapur, Maharashtra</div>
                </div>
                <div className="glass rounded-xl px-4 py-2">
                  <div className="text-xs text-muted-foreground">CGPA</div>
                  <div className="text-2xl font-bold gradient-text">9.22</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Skills() {
  const groups = [
    { icon: Coffee, title: "Programming Languages", items: [
      ["Java", 90], ["Python", 80], ["C++", 75], ["C#", 65],
    ]},
    { icon: Globe, title: "Web Technologies", items: [
      ["HTML", 90], ["CSS", 85], ["JavaScript", 78],
    ]},
    { icon: Wrench, title: "Tools & Platforms", items: [
      ["Git", 85], ["GitHub", 88], ["VS Code", 92],
    ]},
    { icon: Brain, title: "Core Concepts", items: [
      ["DSA", 82], ["OOP", 90], ["Problem Solving", 85], ["Software Dev", 80],
    ]},
  ];
  return (
    <section id="skills" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4">
        <SectionTitle kicker="Skills" title="Tech Stack & Expertise" />
        <div className="grid md:grid-cols-2 gap-6">
          {groups.map((g) => (
            <div key={g.title} className="glass rounded-2xl p-6 reveal-on-scroll hover:glow transition">
              <div className="flex items-center gap-3 mb-5">
                <div className="p-2.5 rounded-xl gradient-bg text-white"><g.icon className="size-5" /></div>
                <h3 className="font-semibold text-lg">{g.title}</h3>
              </div>
              <div className="space-y-4">
                {g.items.map(([name, pct]) => (
                  <div key={name as string}>
                    <div className="flex justify-between text-sm mb-1.5">
                      <span>{name}</span>
                      <span className="text-muted-foreground">{pct}%</span>
                    </div>
                    <div className="h-2 rounded-full bg-white/5 overflow-hidden">
                      <div className="h-full gradient-bg rounded-full transition-all duration-1000" style={{ width: `${pct}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Services() {
  const services = [
    { icon: Globe, title: "Web Development", desc: "Responsive websites with modern UI and clean frontend code." },
    { icon: Database, title: "Full Stack Development", desc: "Frontend + backend apps with database integration and complete web solutions." },
    { icon: Coffee, title: "Java Application Development", desc: "Desktop apps and core Java projects built on solid OOP foundations." },
    { icon: Code2, title: "Software Development", desc: "Software design, development, testing and maintenance." },
  ];
  return (
    <section id="services" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4">
        <SectionTitle kicker="Services" title="What I Can Do" />
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {services.map((s, i) => (
            <div key={s.title} className="group glass rounded-2xl p-6 reveal-on-scroll hover:glow hover:-translate-y-1 transition-all duration-300"
              style={{ animationDelay: `${i * 0.1}s` }}>
              <div className="size-12 rounded-xl gradient-bg flex items-center justify-center text-white mb-4 group-hover:scale-110 transition">
                <s.icon className="size-6" />
              </div>
              <h3 className="font-semibold text-lg mb-2">{s.title}</h3>
              <p className="text-sm text-muted-foreground">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Experience() {
  return (
    <section id="experience" className="py-20 md:py-28">
      <div className="mx-auto max-w-5xl px-4">
        <SectionTitle kicker="Experience" title="Internship Experience" />
        <div className="relative pl-8 md:pl-12">
          <div className="absolute left-2 md:left-4 top-2 bottom-2 w-px gradient-bg" />
          <div className="relative reveal-on-scroll">
            <div className="absolute -left-7 md:-left-10 top-2 size-4 rounded-full gradient-bg glow" />
            <div className="glass rounded-2xl p-6 md:p-8 hover:glow transition">
              <div className="flex flex-wrap items-start justify-between gap-2 mb-3">
                <div>
                  <div className="text-sm text-muted-foreground">Nov 2025 — Dec 2025</div>
                  <h3 className="text-xl md:text-2xl font-bold mt-1">Full Stack Developer Intern</h3>
                  <div className="text-muted-foreground">Skillbit Technologies</div>
                </div>
                <div className="p-3 rounded-xl gradient-bg text-white"><Briefcase className="size-5" /></div>
              </div>
              <ul className="space-y-2 text-sm text-muted-foreground mt-3">
                <li className="flex gap-2"><span className="text-brand mt-1">▸</span> Developed responsive web applications</li>
                <li className="flex gap-2"><span className="text-brand mt-1">▸</span> Worked on frontend and backend development</li>
                <li className="flex gap-2"><span className="text-brand mt-1">▸</span> Enhanced practical software development skills</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Projects() {
  const projects = [
    {
      title: "Online Hospital Management System",
      desc: "Console-based hospital management with patient records, doctor info, appointment scheduling, and file handling.",
      tech: ["C++", "File I/O", "OOP"],
      points: ["Patient record management", "Doctor information", "Appointment scheduling", "File handling"],
    },
    {
      title: "Number Guessing Game",
      desc: "Interactive console-based Java application using loops and conditional logic to sharpen problem-solving.",
      tech: ["Java", "Logic", "CLI"],
      points: ["Random number logic", "Loops & conditions", "User input handling"],
    },
    {
      title: "Attendance Management System",
      desc: "Java-based attendance tracking with student registration, marking, history tracking, and reports.",
      tech: ["Java", "OOP", "Reports"],
      points: ["Student registration", "Attendance marking", "History tracking", "Report generation"],
      link: SOCIALS.github,
    },
  ];
  return (
    <section id="projects" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4">
        <SectionTitle kicker="Projects" title="Featured Work" />
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((p) => (
            <div key={p.title} className="group glass rounded-2xl overflow-hidden reveal-on-scroll hover:glow hover:-translate-y-2 transition-all duration-500">
              <div className="aspect-video gradient-bg relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
                <FolderGit2 className="absolute inset-0 m-auto size-16 text-white/80 group-hover:scale-110 transition" />
              </div>
              <div className="p-6">
                <h3 className="font-bold text-lg mb-2">{p.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">{p.desc}</p>
                <ul className="space-y-1 text-xs text-muted-foreground mb-4">
                  {p.points.map((pt) => (
                    <li key={pt} className="flex gap-2"><span className="text-brand">•</span>{pt}</li>
                  ))}
                </ul>
                <div className="flex flex-wrap gap-2 mb-4">
                  {p.tech.map((t) => (
                    <span key={t} className="px-2.5 py-1 rounded-full text-xs glass">{t}</span>
                  ))}
                </div>
                {p.link && (
                  <a href={p.link} target="_blank" rel="noreferrer"
                    className="inline-flex items-center gap-1.5 text-sm gradient-text font-medium hover:gap-2.5 transition-all">
                    View Project <ExternalLink className="size-3.5" />
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Certifications() {
  const items = [
    { icon: Briefcase, title: "Full Stack Developer Internship", issuer: "Skillbit Technologies", date: "Dec 2025" },
    { icon: Award, title: "Technical Certifications", issuer: "Ongoing", date: "2025 — Present" },
    { icon: GraduationCap, title: "Academic Achievements", issuer: "DYP College of Engineering", date: "CGPA 9.22" },
    { icon: Code2, title: "Coding Achievements", issuer: "LeetCode", date: "Active" },
  ];
  return (
    <section id="certifications" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4">
        <SectionTitle kicker="Achievements" title="Certifications & Awards" />
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {items.map((it) => (
            <div key={it.title} className="glass rounded-2xl p-6 reveal-on-scroll hover:glow hover:-translate-y-1 transition">
              <div className="size-12 rounded-xl gradient-bg flex items-center justify-center text-white mb-4">
                <it.icon className="size-6" />
              </div>
              <h3 className="font-semibold mb-1">{it.title}</h3>
              <div className="text-sm text-muted-foreground">{it.issuer}</div>
              <div className="text-xs text-muted-foreground mt-2">{it.date}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Contact() {
  const [sent, setSent] = useState(false);
  const formRef = useRef<HTMLFormElement>(null);
  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const fd = new FormData(formRef.current!);
    const subject = encodeURIComponent(String(fd.get("subject") || "Portfolio Contact"));
    const body = encodeURIComponent(`Name: ${fd.get("name")}\nEmail: ${fd.get("email")}\n\n${fd.get("message")}`);
    window.location.href = `mailto:${SOCIALS.email}?subject=${subject}&body=${body}`;
    setSent(true);
    setTimeout(() => setSent(false), 3000);
  };
  const info = [
    { icon: Mail, label: "Email", value: SOCIALS.email, href: `mailto:${SOCIALS.email}` },
    { icon: Phone, label: "Phone", value: SOCIALS.phone, href: `tel:${SOCIALS.phone}` },
    { icon: MapPin, label: "Location", value: "Kolhapur, Maharashtra, India" },
    { icon: Linkedin, label: "LinkedIn", value: "rasika-patil", href: SOCIALS.linkedin },
  ];
  return (
    <section id="contact" className="py-20 md:py-28">
      <div className="mx-auto max-w-7xl px-4">
        <SectionTitle kicker="Contact" title="Let's Build Together" subtitle="Open to internships, collaborations, and a good chat about code." />
        <div className="grid lg:grid-cols-[1fr_1.4fr] gap-6">
          <div className="space-y-4 reveal-on-scroll">
            {info.map((i) => {
              const Wrap: any = i.href ? "a" : "div";
              return (
                <Wrap key={i.label} {...(i.href ? { href: i.href } : {})}
                  className="glass rounded-2xl p-5 flex items-center gap-4 hover:glow transition group">
                  <div className="p-3 rounded-xl gradient-bg text-white group-hover:scale-110 transition"><i.icon className="size-5" /></div>
                  <div>
                    <div className="text-xs text-muted-foreground">{i.label}</div>
                    <div className="font-medium text-sm">{i.value}</div>
                  </div>
                </Wrap>
              );
            })}
            <div className="glass rounded-2xl p-5">
              <div className="text-xs text-muted-foreground mb-3">Connect on socials</div>
              <SocialIcons />
            </div>
          </div>
          <form ref={formRef} onSubmit={submit} className="glass rounded-2xl p-6 md:p-8 reveal-on-scroll space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <Field label="Name" name="name" required />
              <Field label="Email" name="email" type="email" required />
            </div>
            <Field label="Subject" name="subject" required />
            <div>
              <label className="block text-sm mb-1.5 text-muted-foreground">Message</label>
              <textarea name="message" required rows={5}
                className="w-full px-4 py-3 rounded-xl bg-white/5 border border-border focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30 transition resize-none" />
            </div>
            <button type="submit"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl gradient-bg text-white font-medium hover:glow hover:-translate-y-0.5 transition w-full justify-center">
              {sent ? "Opening Mail..." : <>Send Message <Send className="size-4" /></>}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

function Field({ label, name, type = "text", required = false }: any) {
  return (
    <div>
      <label className="block text-sm mb-1.5 text-muted-foreground">{label}</label>
      <input name={name} type={type} required={required}
        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-border focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/30 transition" />
    </div>
  );
}

function Footer({ onNav }: { onNav: (id: string) => void }) {
  return (
    <footer className="border-t border-border mt-12">
      <div className="mx-auto max-w-7xl px-4 py-12 grid md:grid-cols-3 gap-8">
        <div>
          <div className="font-display font-bold text-xl"><span className="gradient-text">Rasika</span>.dev</div>
          <p className="text-sm text-muted-foreground mt-3 max-w-xs">
            Computer Science student crafting practical software and learning every day.
          </p>
          <div className="mt-4"><SocialIcons /></div>
        </div>
        <div>
          <div className="font-semibold mb-3">Quick Links</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            {NAV.slice(0, 6).map((n) => (
              <li key={n.id}>
                <button onClick={() => onNav(n.id)} className="hover:text-foreground transition">{n.label}</button>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <div className="font-semibold mb-3">Get in touch</div>
          <div className="text-sm text-muted-foreground space-y-1">
            <div>{SOCIALS.email}</div>
            <div>{SOCIALS.phone}</div>
            <div>Kolhapur, Maharashtra</div>
          </div>
          <a href="/resume.pdf" download
            className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl gradient-bg text-white text-sm font-medium hover:glow transition">
            <Download className="size-4" /> Download Resume
          </a>
        </div>
      </div>
      <div className="border-t border-border py-5 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Rasika Raghunath Patil. Crafted with care.
      </div>
    </footer>
  );
}
