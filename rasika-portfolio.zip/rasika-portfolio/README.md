# Rasika Raghunath Patil - Portfolio Website

A modern, premium-quality personal portfolio website built with React 19, Tailwind CSS v4, Framer Motion, and TanStack Start.

## Features

- Dark theme with glassmorphism design
- Professional profile photo in hero section
- Animated sections with scroll reveal effects
- Typing animation for role titles
- Responsive design for all devices
- SEO optimized with meta tags, OG tags, and structured data
- Contact form with social links
- Downloadable resume button
- Project showcase with hover effects

## Tech Stack

- React 19 + TypeScript
- TanStack Start (file-based routing, SSR)
- Tailwind CSS v4
- Framer Motion (animations)
- shadcn/ui components
- Lucide React icons

## Getting Started

### Prerequisites

- Node.js 18+ or Bun

### Installation

```bash
# Install dependencies
bun install

# Start development server
bun dev
```

### Build for Production

```bash
bun run build
```

## Project Structure

```
src/
├── assets/
│   └── rasika.jpg              # Profile photo
├── components/ui/               # shadcn/ui components
├── hooks/
│   └── use-mobile.tsx          # Mobile detection hook
├── lib/
│   └── utils.ts                # Utility functions
├── routes/
│   ├── __root.tsx              # Root layout (SEO meta, fonts)
│   └── index.tsx               # Main portfolio page (all sections)
├── router.tsx                  # TanStack Router config
├── server.ts                   # Server entry
├── start.ts                    # App start config
├── routeTree.gen.ts            # Auto-generated route tree
└── styles.css                  # Tailwind CSS + custom design tokens
```

## Customization

### Update Profile Information

Edit `src/routes/index.tsx` to update:
- Name, title, and tagline
- Education details
- Skills and technologies
- Projects
- Experience
- Certifications
- Contact information
- Social media links

### Replace Profile Photo

Replace `src/assets/rasika.jpg` with your own image.

### Update Resume

Place your resume PDF at `public/resume.pdf` and update the download button link in the Hero section.

### Change Colors/Theme

Edit `src/styles.css` to customize:
- Color palette (CSS variables)
- Font choices
- Animation timings
- Glassmorphism effects

## Sections

1. **Navigation** - Fixed top nav with smooth scroll
2. **Hero** - Profile photo, name, typing animation, CTA buttons
3. **About** - Professional summary
4. **Education** - Academic background with CGPA
5. **Skills** - Technical skills with categorized tags
6. **Services** - What I can offer
7. **Experience** - Work and project experience
8. **Projects** - Featured projects with links
9. **Certifications** - Credentials and achievements
10. **Contact** - Contact form + social links
11. **Footer** - Copyright and quick links

## License

Personal use only.

---

Built with ❤️ for Rasika Raghunath Patil
